"""
Business Entity Resolution Package
"""
